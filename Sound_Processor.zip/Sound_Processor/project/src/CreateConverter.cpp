#include "CreateConverter.h"

std::string CreateConverter::GetConvertersInfo() {

	return this->converterInfo;
}

std::string CreateConverter::UsingInfo() {
	return this->usingInfo;
}

CreateMute::CreateMute() {
	this->converterInfo += "Mute converter mutes given interval of file (in seconds)\n";
	this->converterInfo += "Default: \t0 parameters given - mutes all file\n";
	this->converterInfo += "\t1 parameter given - mutes from the given time to the end of the file\n";
	this->converterInfo += "\t2 parameters given - mutes the file in given interval (in seconds)\n";

	this->usingInfo += "Format in config file:\n";
	this->usingInfo += "mute [format] [integer parameters]\n";
	this->usingInfo += "format: $1 - there can only be one input file\n";
	this->usingInfo += "integer parameters: max integer parameters amount = 2\n";
}

Converter* CreateMute::Create(std::vector<int>& intervals) {
	return new Mute(intervals);
}


CreateMix::CreateMix() {
	this->converterInfo += "Mix converter mixes given files in given interval (in seconds)\n";
	this->converterInfo += "Default: \t0 parameters given - mixes all files from start to end\n";
	this->converterInfo += "\t1 parameter given - mixes all files from given time (in seconds) to the end of the file\n";
	this->converterInfo += "\t(if it was the first configuration, then it depends on the size of the first input file, else it depends on the size of output file)\n";
	this->converterInfo += "\t2 parameters given - mutes the file in given interval (in seconds)\n";

	this->usingInfo += "Format in config file:\n";
	this->usingInfo += "mix [format] [interger parameters]\n";
	this->usingInfo += "format: $n, where n - index of input file\n";
	this->usingInfo += "integer parameters: max integer parameters amount = 2\n";
}

Converter* CreateMix::Create(std::vector<int>& intervals) {
	return new Mix(intervals);
}


CreateReverb::CreateReverb() {
	this->converterInfo += "Reverb makes music a little bit more realistic (adds echo effect)\n";
	this->converterInfo += "Default: \t0 parameters given - mutes all file\n";
	this->converterInfo += "\t1 parameter given - mutes from the given time to the end of the file\n";
	this->converterInfo += "\t2 parameters given - mutes the file in given interval (in seconds)\n";
	this->converterInfo += "Mix converter mixes given files in given interval (in seconds)\n";

	this->usingInfo += "Format in config file:\n";
	this->usingInfo += "mix [format] [interger parameters]\n";
	this->usingInfo += "format: $1 - there can only be one input file\n";
	this->usingInfo += "integer parameters: max integer parameters amount = 2\n";
}

Converter* CreateReverb::Create(std::vector<int>& intervals) {
	return new Reverb(intervals);
}
