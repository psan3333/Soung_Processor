#include "wave_file.h"

void Wave_File::AllocateCharFields() {

	this->riffChunkID = new char[5];
	this->riffChunkID[4] = '\0';

	this->fileFormat = new char[5];
	this->fileFormat[4] = '\0';

	this->fmtChunkID = new char[5];
	this->fmtChunkID[4] = 0;

	this->listChunkID = new char[5];
	this->listChunkID[4] = '\0';

	this->infoID = new char[5];
	this->infoID[4] = '\0';

	this->fileDesc = new char[5];
	this->fileDesc[4] = '\0';

	this->dataChunkID = new char[5];
	this->dataChunkID[4] = '\0';
}

void Wave_File::ReadChunksFromFile() {

	if (!this->file.is_open()) {
		std::cerr << "file did not open (ReadChunksFromFile function, wave.cpp)" << std::endl << std::endl;
		exit(1);
	}

 	AllocateCharFields();

	//������ ������� ���������� ��� ������ ������������ ������� ����� (�� ������� ������) 

	this->file.read(this->riffChunkID, 4);
	if (std::string(this->riffChunkID) != std::string("RIFF")) {
		std::cerr << "wrong riff chunk name parameter (not 'RIFF') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(2);
	}

	this->file.read((char*)&this->riffChunkSize, 4);

	this->file.read(this->fileFormat, 4);
	if (std::string(this->fileFormat) != std::string("WAVE")) {
		std::cerr << "wrong file format parameter (not 'WAVE') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(3);
	}

	this->file.read(this->fmtChunkID, 4);
	if (std::string(this->fmtChunkID) != std::string("fmt ")) {
		std::cerr << "wrong format chunk name parameter (not 'fmt ') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(4);
	}

	this->file.read((char*)&this->fmtChunkSize, 4);
	if (this->fmtChunkSize != 16) {
		std::cerr << "wrong fmt chunk size (must be 16 bytes) (ReadChunksFromFile function, wave.cpp)" << std::endl << std::endl;
		exit(5);
	}

	this->file.read((char*)&this->audioFormat, 2);
	if (this->audioFormat != 1) {
		std::cerr << "wrong audio format parameter (must be equal to 1 - PCM) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(6);
	}

	this->file.read((char*)&this->numChannels, 2);
	if (this->numChannels != 1) {
		std::cerr << "wrong number of channels in file parameter (must be equal to 1) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(7);
	}

	this->file.read((char*)&this->sampleRate, 4);
	if (this->sampleRate != 44100) {
		std::cerr << "wrong sample rate parameter (must be equal to 44100) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(8);
	}

	this->file.read((char*)&this->byteRate, 4);
	if (byteRate != this->sampleRate * 2) {
		std::cerr << "wrong byte rate parameter (must be equal to 88200 - sampleRate * bitsPerSample / 8) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(9);
	}

	this->file.read((char*)&this->blockAlign, 2);
	if (this->blockAlign != 2) {
		std::cerr << "wrong block align parameter (must be equal to 2) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(10);
	}

	this->file.read((char*)&this->bitsPerSample, 2);
	if (bitsPerSample != 16) {
		std::cerr << "wrong bits per sample parameter (must be equal to 16) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(11);
	}

	this->file.read(this->listChunkID, 4);
	if (std::string(this->listChunkID) != std::string("LIST")) {
		std::cerr << "wrong list chunk name parameter (not 'LIST') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(12);
	}

	this->file.read((char*)&this->listChunkSize, 4);
	if (this->listChunkSize < 8) {
		std::cerr << "wrong list chunk size (must be >= 8) (ReadChunksFromFile function, wave_file.cpp)";
		exit(13);
	}

	this->file.read(this->infoID, 4);
	if (std::string(this->infoID) != std::string("INFO")) {
		std::cerr << "wrong info chunk name parameter (not 'INFO') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(14);
	}

	this->file.read(this->fileDesc, 4);
	if (std::string(this->fileDesc) != std::string("IART")) {
		std::cerr << "wrong file descroption format (not 'IART') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(15);
	}

	int currentPointerPosition = this->file.tellp();
	this->file.seekp(currentPointerPosition + this->listChunkSize - 8); //8 - infoID + fileDesc

	this->file.read(this->dataChunkID, 4);
	if (std::string(this->dataChunkID) != std::string("data")) {
		std::cerr << "wrong data chunk name parameter (not 'data') (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(16);
	}

	this->file.read((char*)&this->dataChunkSize, 4); //��������� �������
	if (riffChunkSize - dataChunkSize - fmtChunkSize - listChunkSize - 8 * 3 - 12 != -8) {
		std::cerr << "wrong data chunk size value \n(must be riffChunkSize - dataChunkSize - fmtChunkSize - listChunkSize - 8 * 3 - 12 equal to -8) (ReadChunksFromFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(17);
	}

	this->filePtr = this->file.tellp();
}

std::vector<std::complex<double>> Wave_File::ReadSecond(bool keepPointer, int cnt) { //������� ���������� �� �������

	std::vector<std::complex<double>> sampleBytes;

	if ((this->mode != (std::ios::binary | std::ios::in)) && (this->mode != (std::ios::binary | std::ios::in | std::ios::out))) {
		std::cerr << "wrong file mode \n(must be std::ios::binary | std::ios::in or std::ios::binary | std::ios::in | std::ios::out) (ReadSample function, wave_file.cpp)" << std::endl << std::endl;
		exit(18);
	}

	this->file.seekp(this->filePtr);

	for (int i = 0; i < cnt; i++) {
		if (this->samplesRW == this->dataChunkSize) {
			break;
		}
		short sampleByte;
		this->file.read((char*)&sampleByte, 2);
		sampleBytes.push_back(std::complex<double>((double)sampleByte, 0.0));
		if (this->mode == (std::ios::binary | std::ios::in)) {
			this->samplesRW += 2;
		}
	}

	if (this->samplesRW > this->dataChunkSize) {
		std::cerr << "wrong data chunk size (read to much data) (ReadSample, wave_file.cpp)" << std::endl << std::endl;
		exit(19);
	}

	if ((this->mode == (std::ios::binary | std::ios::in | std::ios::out)) && keepPointer) {
		this->file.seekp(this->filePtr);
	}
	else {
		this->filePtr = this->file.tellp();
	}

	return sampleBytes;
}

void Wave_File::WriteSecondToFile(std::vector<std::complex<double>>& samples) { //������� ������ �� �������

	if (this->mode != (std::ios::binary | std::ios::out | std::ios::in)) {
		std::cerr << "wrong file mode (must be std::ios::binary | std::ios::in | std::ios::out) (WriteToSampleFile function, wave_file.cpp)" << std::endl << std::endl;
		exit(20);
	}

	for (int i = 0; i < samples.size(); i++) {
		short sample = (short)samples[i].real();
		this->file.write((char*)&sample, 2);
		this->samplesRW += 2;
	}

	this->filePtr = this->file.tellp();
}

void Wave_File::DefineSize() {
	if (this->mode != (std::ios::binary | std::ios::out | std::ios::in)) {
		std::cerr << "tries to resize input file (DefineSize function, wave_file.cpp)" << std::endl << std::endl;
		exit(21);
	}

	this->dataChunkSize = this->samplesRW;
	this->samplesRW = 0;
	this->riffChunkSize = this->dataChunkSize + this->fmtChunkSize + this->listChunkSize + 8 * 3 + 12 - 8;

	if (this->file.is_open()) {
		this->file.close();
	}
	this->file.open(this->fileName, this->mode);

	if (this->file.is_open()) {
		int k = 0;
	}

	//���������� ������ ����� (fileSize - 8)
	this->file.seekp(4);
	this->file.write((char*)&this->riffChunkSize, 4);

	//���������� ������ ������ �����
	this->file.seekp(12 + 8 + this->fmtChunkSize + 8 + this->listChunkSize + 4);
	this->file.write((char*)&this->dataChunkSize, 4);

	this->filePtr = this->file.tellp();
}

bool Wave_File::EndOfFile() {
	if (this->samplesRW >= this->dataChunkSize) {
		return true;
	}
	return false;
}

void Wave_File::PrepareOutputFile() {

	this->file.close();

	std::ofstream out(this->fileName);
	out.close();

	this->file.open(this->fileName, this->mode);

	this->riffChunkID = const_cast<char*>("RIFF");
	this->fileFormat = const_cast<char*>("WAVE");
	this->fmtChunkID = const_cast<char*>("fmt ");
	this->fmtChunkSize = 16;
	this->audioFormat = 1;
	this->numChannels = 1;
	this->sampleRate = 44100;
	this->byteRate = 2 * this->sampleRate;
	this->blockAlign = 2;
	this->bitsPerSample = 16;
	this->listChunkID = const_cast<char*>("LIST");
	this->listChunkSize = 8; //���������� � ����� ��������� �� �����, ������ ��������
	this->infoID = const_cast<char*>("INFO");
	this->fileDesc = const_cast<char*>("IART");
	this->dataChunkID = const_cast<char*>("data");

	//���������� ������ � �������������� �����
	this->file.write(this->riffChunkID, 4);

	this->file.write("----", 4);

	this->file.write(this->fileFormat, 4);

	this->file.write(this->fmtChunkID, 4);

	this->file.write((char*)&this->fmtChunkSize, 4);

	this->file.write((char*)&this->audioFormat, 2);

	this->file.write((char*)&this->numChannels, 2);

	this->file.write((char*)&this->sampleRate, 4);

	this->file.write((char*)&this->byteRate, 4);

	this->file.write((char*)&this->blockAlign, 2);

	this->file.write((char*)&this->bitsPerSample, 2);

	this->file.write(this->listChunkID, 4);

	this->file.write((char*)&this->listChunkSize, 4);

	this->file.write(this->infoID, 4);

	this->file.write(this->fileDesc, 4);

	this->file.write(this->dataChunkID, 4);

	this->file.write("----", 4);

	this->filePtr = this->file.tellp();
	//��������� ��������� ����� ���������� � �������� �����������
	//������������: ������ ����� riffChunkSize � ������ ������ ����� dataChunkSize
}


Wave_File::Wave_File() {
	this->fileName = nullptr;
	this->filePtr = 0;
	this->riffChunkID = nullptr;
	this->fileFormat = nullptr;
	this->fmtChunkID = nullptr;
	this->listChunkID = nullptr;
	this->infoID = nullptr;
	this->fileDesc = nullptr;
	this->dataChunkID = nullptr;
	this->mode = 0;
	this->samplesRW = 0;
	this->riffChunkSize = 0;
	this->fmtChunkSize = 0;
	this->audioFormat = 0;
	this->numChannels = 0;
	this->sampleRate = 0;
	this->byteRate = 0;
	this->blockAlign = 0;
	this->bitsPerSample = 0;
	this->listChunkSize = 0;
	this->dataChunkSize = 0;
}

Wave_File::Wave_File(char* file_name, int mode) {

	this->fileName = file_name;
	this->mode = mode;

	if ((mode != (std::ios::binary | std::ios::in)) && (mode != (std::ios::in | std::ios::out | std::ios::binary))) {
		std::cerr << "wrong file mode \n(must be std::ios::binary | std::ios::in or std::ios::binary | std::ios::in | std::ios::out) (ReadSample function, wave_file.cpp)" << std::endl << std::endl;
		exit(22);
	}

	this->samplesRW = 0;
	this->file.open(this->fileName, this->mode);

	std::string wav = ".wav";
	int cnt = 0, i = 0;
	while (file_name[i] != '\0') {
		if (file_name[i] == wav[cnt]) {
			cnt++;
		}
		i++;
	}

	if (cnt != wav.size()) {
		std::cerr << "wrong file format (must be *.wav file) (Wave_File(char*, int) constructor, wave_file.cpp)" << std::endl << std::endl;
		exit(23);
	}

	if (mode == (std::ios::in | std::ios::binary)) {
		ReadChunksFromFile();
	}
	else {
		AllocateCharFields();

		PrepareOutputFile();
	}	
}

Wave_File::Wave_File(const Wave_File& wave_file) {
	Wave_File* link = (Wave_File*)const_cast<Wave_File*>(&wave_file);
	if (link->file.is_open()) {
		link->file.close();
	}
	this->file.open(wave_file.fileName, wave_file.mode); //file
	this->filePtr = link->filePtr;
	this->file.seekp(this->filePtr);

	this->mode = wave_file.mode; //����� ������-������
	this->samplesRW = wave_file.samplesRW; //��� ������ ������, ����� �������� � ���� ����������� ���-�� ���� 
	this->fileName = wave_file.fileName;
	//file data
	this->riffChunkID = wave_file.riffChunkID; //4
	this->riffChunkSize = wave_file.riffChunkSize; //4
	this->fileFormat = wave_file.fileFormat; //4

	this->fmtChunkID = wave_file.fmtChunkID; //4
	this->fmtChunkSize = wave_file.fmtChunkSize; //4
	this->audioFormat = wave_file.audioFormat; //2
	this->numChannels = wave_file.numChannels; //2
	this->sampleRate = wave_file.sampleRate; //4
	this->byteRate = wave_file.byteRate; //4
	this->blockAlign = wave_file.blockAlign; //2
	this->bitsPerSample = wave_file.bitsPerSample; //2

	this->listChunkID = wave_file.listChunkID; //4
	this->listChunkSize = wave_file.listChunkSize; //4
	this->infoID = wave_file.infoID; //4
	this->fileDesc = wave_file.fileDesc; //4

	this->dataChunkID = wave_file.dataChunkID; //4
	this->dataChunkSize = wave_file.dataChunkSize; //4
}

Wave_File& Wave_File::operator=(const Wave_File& wave_file) {
	Wave_File* link = (Wave_File*)const_cast<Wave_File*>(&wave_file);
	if (link->file.is_open()) {
		link->file.close();
	}
	this->file.open(wave_file.fileName, wave_file.mode); //file
	this->filePtr = link->filePtr;
	this->file.seekp(this->filePtr);

	this->mode = wave_file.mode; //����� ������-������
	this->samplesRW = wave_file.samplesRW; //��� ������ ������, ����� �������� � ���� ����������� ���-�� ���� 
	this->fileName = wave_file.fileName;
	//file data
	this->riffChunkID = wave_file.riffChunkID; //4
	this->riffChunkSize = wave_file.riffChunkSize; //4
	this->fileFormat = wave_file.fileFormat; //4

	this->fmtChunkID = wave_file.fmtChunkID; //4
	this->fmtChunkSize = wave_file.fmtChunkSize; //4
	this->audioFormat = wave_file.audioFormat; //2
	this->numChannels = wave_file.numChannels; //2
	this->sampleRate = wave_file.sampleRate; //4
	this->byteRate = wave_file.byteRate; //4
	this->blockAlign = wave_file.blockAlign; //2
	this->bitsPerSample = wave_file.bitsPerSample; //2

	this->listChunkID = wave_file.listChunkID; //4
	this->listChunkSize = wave_file.listChunkSize; //4
	this->infoID = wave_file.infoID; //4
	this->fileDesc = wave_file.fileDesc; //4

	this->dataChunkID = wave_file.dataChunkID; //4
	this->dataChunkSize = wave_file.dataChunkSize; //4

	return *this;
}
