#include "Processor.h"

//��������� ���� ������

void Processor::PrintInfo() {
	//�������!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	CreateMix mix;
	CreateMute mute;
	CreateReverb reverb;

	std::cout << "Info:" << std::endl << std::endl;

	std::cout << "This programm can be used to mix, mute and reverberate songs" << std::endl << std::endl;

	std::cout << "Converters:" << std::endl;

	std::cout << mix.GetConvertersInfo() << std::endl;
	std::cout << mute.GetConvertersInfo() << std::endl;
	std::cout << reverb.GetConvertersInfo() << std::endl;

	std::cout << std::endl << "How to use converters";

	std::cout << "Example:\nSound_Processor.exe [-h] -c config.txt output.wav input1.wav ... inputN.wav" << std::endl;
	std::cout << "-h - prints information about programm" << std::endl;
	std::cout << "-c config.txt - configuration file" << std::endl;
	std::cout << "output.wav - result of configurations in file config.txt" << std::endl;
	std::cout << "input1.wav ... - input files" << std::endl << std::endl;

	std::cout << mix.UsingInfo() << std::endl;
	std::cout << mute.UsingInfo() << std::endl;
	std::cout << reverb.UsingInfo() << std::endl;
}

bool Processor::IsDigit(std::string& num) {

	for (int i = 0; i < num.size(); i++) {
		if ((int)num[i] < 48 || (int)num[i] > 57) {
			return false;
		}
	}

	return true;
}

bool Processor::CheckAndInit(int argc, char** argv) {
	//��������� ������ �������

	if (argc < 2) {
		std::cerr << "Not enought parameters (CheckAndInit, Processor.cpp)" << this->help << std::endl << std::endl;
		exit(24);
	}

	std::string toDoInfo = "-h";
	std::string toDoConfig = "-c";
	this->inc = 0;

	if (std::string(argv[1]) == toDoInfo) {
		PrintInfo();
		if (argc == 2) {
			return true;
		}
		this->inc = 1;
	}
	if (std::string(argv[1 + this->inc]) != toDoConfig) {
		std::cerr << "wrong command parameter (CheckAndInit function, Processor.cpp)" << this->help << std::endl << std::endl;
		exit(25);
	}

	this->config.open(argv[2 + this->inc], std::ios::in);
	if (!this->config.is_open()) {
		std::cerr << "configuration file not found (CheckAndInit function, Processor.cpp)" << this->help << std::endl << std::endl;
		exit(26);
	}

	return false;
}

std::vector<int> Processor::ParseFormat(std::vector<std::string>& format) {
	std::vector<int> indexes;

	int i = 0;
	while (i < format.size()) {
		if (format[i][0] == '$') {
			int num = 0;
			for (int j = 1; j < format[i].size(); j++) {
				if ((int)format[i][j] >= 48 && (int)format[i][j] <= 57) {
					num *= 10;
					num += (int)format[i][j] - 48;
				}
				else {
					std::cerr << "wrong paramter " << format[i] << " (ParseFormat function, Processor.cpp)" << this->help << std::endl;
					exit(27);
					break;
				}
			}
			indexes.push_back(num);
		}
		i++;
	}

	return indexes;
}

std::vector<int> Processor::ParseInterval(std::vector<std::string>& format) {
	std::vector<int> params;

	for (int i = 0; i < format.size(); i++) {
		if (IsDigit(format[i])) {
			int num = 0;
			for (int j = 0; j < format[i].size(); j++) {
				num *= 10;
				num += (int)format[i][j] - 48;
			}
			params.push_back(num);
		}
	}

	return params;
}

void Processor::InitConverter(std::string& command, std::vector<int>& intervals) {

	//mute, mix, change volume (�����������), bass boost (main feature for future)))) 
	if (command == std::string("mix")) {
		CreateMix mix;
		this->creator = &mix;
	}
	else if (command == std::string("mute")) {
		CreateMute mute;
		this->creator = &mute;
	}
	else if (command == std::string("reverb")) {
		CreateReverb reverb;
		this->creator = &reverb;
	}
	else {
		std::cerr << "this configuration will not be executed (InitConverter, Processor.cpp)" << this->help << command << std::endl << std::endl;
		exit(28);
	}

	this->converter = this->creator->Create(intervals);
}

void Processor::Convert(char** argv, std::vector<int>& fileParams, std::vector<int>& fileIntervals) {
	std::vector<Wave_File> inputFiles;

	for (int i = 0; i < fileParams.size(); i++) {
		Wave_File vec(argv[fileParams[i] + 3 + this->inc], std::ios::binary | std::ios::in);
		inputFiles.push_back(vec); //������ ������� �����
	}

	if (this->converter->GetType() == std::string("mute") || this->converter->GetType() == std::string("reverb")) {
		if (inputFiles.size() == 0 && !this->outputUsed) {
			Wave_File vec(argv[4 + this->inc], std::ios::binary | std::ios::in);
			inputFiles.push_back(vec);
		}
	}
	else if (this->converter->GetType() == std::string("mix")) {
		if (inputFiles.size() == 1 && !this->outputUsed) {
			Wave_File vec(argv[4 + this->inc], std::ios::binary | std::ios::in);
			inputFiles.push_back(vec);
		}
	}

	if (this->outputUsed) {
		inputFiles.push_back(this->mixedFile);
	}

	if (this->converter->GetType() == std::string("reverb")) {

		if (inputFiles.size() > 1) {
			std::cerr << "wrong format (reverb can make reverbration only on 1 file to be written to output file) (Convert function, Processor.cpp)" << this->help << std::endl << std::endl;
			exit(29);
		}

		std::vector<std::vector<std::complex<double>>> firstHalfOfSec;
		
		//��������� ������ ���������� � prevSample ��� ����, ����� � ���������� �� ������������ ��� reverbration
		for (int i = 0; i < inputFiles.size(); i++) {
			std::vector<std::complex<double>> read = inputFiles[i].ReadSecond(true, 22050);
			firstHalfOfSec.push_back(read);
		}
		this->mixedFile.WriteSecondToFile(firstHalfOfSec[firstHalfOfSec.size() - 1]);
		while (true) { //������� �����������

			std::vector<std::vector<std::complex<double>>> secondHalfOfSec;
			bool eof = false;
			for (int i = 0; i < inputFiles.size(); i++) {
				if (inputFiles[i].EndOfFile()) {
					eof = true;
					break;
				}
				std::vector<std::complex<double>> read = inputFiles[i].ReadSecond(true, 22050);
				secondHalfOfSec.push_back(read);
			}

			if (eof) {
				if (!this->outputUsed) {
					this->outputUsed = true;
				}
				else if (this->outputUsed) {
					this->mixedFile = inputFiles[inputFiles.size() - 1];

					std::vector<std::vector<std::complex<double>>> sec_half_of_sec;
					std::vector<std::vector<std::complex<double>>> first_half_of_sec(1, firstHalfOfSec[firstHalfOfSec.size() - 1]);

					while (true) {
						if (this->mixedFile.EndOfFile()) {
							break;
						}
						std::vector<std::complex<double>> read = this->mixedFile.ReadSecond(true, 22050);
						sec_half_of_sec.push_back(read);

						auto iter = first_half_of_sec.cend();
						first_half_of_sec.insert(iter, sec_half_of_sec.begin(), sec_half_of_sec.end());

						this->converter->NewSample(first_half_of_sec);

						this->mixedFile.WriteSecondToFile(first_half_of_sec[1]);

						first_half_of_sec = sec_half_of_sec;
					}
				}

				this->mixedFile.DefineSize();
				return;
			}

			auto iter = firstHalfOfSec.cend();
			firstHalfOfSec.insert(iter, secondHalfOfSec.begin(), secondHalfOfSec.end());

			this->converter->NewSample(firstHalfOfSec);

			if (!this->outputUsed) {
				this->mixedFile.WriteSecondToFile(firstHalfOfSec[1]);
			}
			else {
				inputFiles[inputFiles.size() - 1].WriteSecondToFile(firstHalfOfSec[1]);
			}

			firstHalfOfSec = secondHalfOfSec;
		}
	}
	else {
		while (true) { //������� �����������

			std::vector<std::vector<std::complex<double>>> seconds;
			bool eof = false;
			for (int i = 0; i < inputFiles.size(); i++) {
				if (inputFiles[i].EndOfFile()) {
					eof = true;
					break;
				}
				std::vector<std::complex<double>> readSecond = inputFiles[i].ReadSecond(true, 44100);
				seconds.push_back(readSecond);
			}

			if (eof && !this->outputUsed) {
				this->mixedFile.DefineSize();
				this->outputUsed = true;
				return;
			}
			else if (eof && this->outputUsed) {
				this->mixedFile = inputFiles[inputFiles.size() - 1];
				this->mixedFile.DefineSize(); //��������� ��� ��� �����������������
				return;
			}

			this->converter->NewSample(seconds);

			if (!this->outputUsed) {
				this->mixedFile.WriteSecondToFile(seconds[seconds.size() - 1]);
			}
			else {
				inputFiles[inputFiles.size() - 1].WriteSecondToFile(seconds[seconds.size() - 1]);
			}
		}
	}
}

void Processor::DoConfigCommand(char** argv, std::string& line) {

	std::istringstream str_stream(line);

	std::string command;

	std::vector<std::string> format;

	str_stream >> command;

	if (command[0] == '#') {
		return;
	}

	bool goodLine = true;
	while (!str_stream.eof()) {
		std::string fmt;
		str_stream >> fmt;
		if (fmt[0] == '#') {
			std::cerr << "wrong parameter " << fmt << " (DoConfigCommand, Processor.cpp)" << this->help << std::endl;
			exit(30);
		}
		if (!IsDigit(fmt)) {
			if (fmt[0] != '$') {
				std::cerr << "wrong parameter " << fmt << " (DoConfigCommand, Processor.cpp)" << this->help << std::endl;
				exit(31);
			}
		}
		format.push_back(fmt);
	}


	std::vector<int> fileParams = ParseFormat(format);

	std::vector<int> indexes = ParseInterval(format);

	InitConverter(command, indexes);

	Convert(argv, fileParams, indexes);
}

Processor::Processor(int argc, char** argv) {

	this->help = "\nPrint 'Sound_Processor.exe -h' to see how to use this program";
	bool check = CheckAndInit(argc, argv);

	if (check) {
		return;
	}

	this->outputUsed = false;

	this->mixedFile = Wave_File(argv[3 + this->inc], std::ios::binary | std::ios::out | std::ios::in);

	while (!this->config.eof()) {
		std::string line;
		getline(this->config, line);

		if (line[0] == '#') {
			continue; 
		}

		DoConfigCommand(argv, line);
	}
}