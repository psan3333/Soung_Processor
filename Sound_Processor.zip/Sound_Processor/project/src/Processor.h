#include "CreateConverter.h"
#include "wave_file.h"
#include <sstream>

class Processor { //���������� ����������� ����� ������������
public:

	Processor(int argc, char** argv);

private:

	//methods
	bool IsDigit(std::string& num);
	bool CheckAndInit(int argc, char** argv);
	
	void PrintInfo();
	void DoConfigCommand(char** argv, std::string& line);
	void InitConverter(std::string& command, std::vector<int>& intervals);
	void Convert(char** argv, std::vector<int>& fileParams, std::vector<int>& fileIntervals);

	std::vector<int> ParseFormat(std::vector<std::string>& format);
	std::vector<int> ParseInterval(std::vector<std::string>& format);

	//fields
	bool				   outputUsed;
	int					   inc;
	Converter			   *converter;
	CreateConverter		   *creator;
	Wave_File			   mixedFile;
	std::ifstream		   config;
	std::string			   help;
};